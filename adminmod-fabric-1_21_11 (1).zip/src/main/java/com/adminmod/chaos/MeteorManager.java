package com.adminmod.chaos;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Метеоритный дождь: метеориты летят вниз, оставляя огненный след, и взрываются при ударе. */
public final class MeteorManager {
    private static final class Rain {
        final ServerWorld world;
        final Vec3d center;
        final MeteorSettings settings;
        int spawned = 0;
        int timer = 0;

        Rain(ServerWorld world, Vec3d center, MeteorSettings settings) {
            this.world = world;
            this.center = center;
            this.settings = settings;
        }
    }

    private static final class Meteor {
        final ServerWorld world;
        final MeteorSettings settings;
        Vec3d pos;
        final Vec3d vel;
        int age = 0;

        Meteor(ServerWorld world, Vec3d pos, Vec3d vel, MeteorSettings settings) {
            this.world = world;
            this.pos = pos;
            this.vel = vel;
            this.settings = settings;
        }
    }

    private static final int MAX_RAINS = 10;
    private static final int MAX_METEORS = 400;

    private static final List<Rain> RAINS = new ArrayList<>();
    private static final List<Meteor> METEORS = new ArrayList<>();

    private MeteorManager() {
    }

    public static void start(ServerWorld world, Vec3d center, MeteorSettings settings) {
        if (RAINS.size() < MAX_RAINS) {
            RAINS.add(new Rain(world, center, settings.copy()));
        }
    }

    public static void clear() {
        RAINS.clear();
        METEORS.clear();
    }

    public static void tick() {
        Iterator<Rain> rains = RAINS.iterator();
        while (rains.hasNext()) {
            Rain rain = rains.next();
            if (rain.timer-- <= 0) {
                rain.timer = rain.settings.interval;
                spawnMeteor(rain);
                rain.spawned++;
            }
            if (rain.spawned >= rain.settings.count) {
                rains.remove();
            }
        }
        Iterator<Meteor> meteors = METEORS.iterator();
        while (meteors.hasNext()) {
            if (step(meteors.next())) {
                meteors.remove();
            }
        }
    }

    private static void spawnMeteor(Rain rain) {
        if (METEORS.size() >= MAX_METEORS) {
            return;
        }
        ThreadLocalRandom random = ThreadLocalRandom.current();
        MeteorSettings s = rain.settings;
        double angle = random.nextDouble() * Math.PI * 2;
        double distance = Math.sqrt(random.nextDouble()) * s.radius;
        double driftX = (random.nextDouble() - 0.5) * 0.6 * s.speed;
        double driftZ = (random.nextDouble() - 0.5) * 0.6 * s.speed;
        // стартуем со сдвигом назад по дрейфу, чтобы метеорит упал примерно в выбранную точку
        double fallTicks = s.height / s.speed;
        Vec3d start = new Vec3d(
                rain.center.x + Math.cos(angle) * distance - driftX * fallTicks,
                rain.center.y + s.height,
                rain.center.z + Math.sin(angle) * distance - driftZ * fallTicks);
        METEORS.add(new Meteor(rain.world, start, new Vec3d(driftX, -s.speed, driftZ), s));
    }

    /** @return true, если метеорит закончил полёт */
    private static boolean step(Meteor m) {
        int sub = (int) Math.max(1, Math.ceil(m.vel.length() / 0.5));
        Vec3d stepVec = m.vel.multiply(1.0 / sub);
        for (int i = 0; i < sub; i++) {
            m.pos = m.pos.add(stepVec);
            if (m.pos.y < m.world.getBottomY()) {
                return true;
            }
            BlockPos blockPos = BlockPos.ofFloored(m.pos);
            if (!Targets.loaded(m.world, blockPos)) {
                return true;
            }
            if (!m.world.getBlockState(blockPos).isAir()) {
                Targets.explode(m.world, m.pos, m.settings.power, m.settings.fire, m.settings.breakBlocks);
                return true;
            }
        }
        // частицы через тик и поменьше: так меньше трафика при большом дожде
        if (m.age++ % 2 == 0) {
            m.world.spawnParticles(ParticleTypes.FLAME, m.pos.x, m.pos.y, m.pos.z, 6, 0.3, 0.3, 0.3, 0.02);
            m.world.spawnParticles(ParticleTypes.LARGE_SMOKE, m.pos.x, m.pos.y, m.pos.z, 2, 0.3, 0.3, 0.3, 0.0);
        }
        return false;
    }
}
