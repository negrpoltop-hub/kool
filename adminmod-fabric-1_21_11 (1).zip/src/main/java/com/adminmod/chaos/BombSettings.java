package com.adminmod.chaos;

/** Настройки бомбы из руки (у каждого админа свои). */
public final class BombSettings {
    public boolean enabled = true;  // жезл работает
    public double power = 4.0;      // сила взрыва
    public double speed = 2.0;      // скорость полёта, блоков/тик
    public double gravity = 0.0;    // падение бомбы (0 = летит прямо)
    public int count = 1;           // бомб за один бросок
    public double spread = 0.0;     // разброс при нескольких бомбах
    public int cooldown = 10;       // перезарядка в тиках
    public boolean fire = false;    // поджигать
    public boolean breakBlocks = true; // ломать блоки

    public BombSettings copy() {
        BombSettings c = new BombSettings();
        c.enabled = enabled;
        c.power = power;
        c.speed = speed;
        c.gravity = gravity;
        c.count = count;
        c.spread = spread;
        c.cooldown = cooldown;
        c.fire = fire;
        c.breakBlocks = breakBlocks;
        return c;
    }
}
