package com.adminmod.npc;

import com.adminmod.Config;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** НПС-раздатчики: неподвижные неуязвимые мобы, которые по правому клику выдают предмет с выбранными зачарованиями. */
public final class NpcManager {
    private static final Map<String, Long> LAST_USE = new HashMap<>();

    private NpcManager() {
    }

    public static void clear() {
        LAST_USE.clear();
    }

    public static boolean create(ServerWorld world, BlockPos pos, NpcDef def, EntityType<?> type) {
        Entity spawned = type.spawn(world, pos, SpawnReason.COMMAND);
        if (!(spawned instanceof MobEntity mob)) {
            if (spawned != null) {
                spawned.discard();
            }
            return false;
        }
        mob.setAiDisabled(true);
        mob.setInvulnerable(true);
        mob.setPersistent();
        mob.setSilent(true);
        mob.setCustomName(Text.literal(def.name));
        mob.setCustomNameVisible(true);
        Config.get().npcs.put(mob.getUuid().toString(), def);
        Config.save();
        return true;
    }

    /** Удаляет ближайшего НПС в радиусе 6 блоков. */
    public static boolean removeNearest(ServerWorld world, BlockPos center) {
        Box box = new Box(center).expand(6.0);
        List<MobEntity> found = world.getEntitiesByClass(MobEntity.class, box,
                mob -> Config.get().npcs.containsKey(mob.getUuid().toString()));
        if (found.isEmpty()) {
            return false;
        }
        MobEntity nearest = found.stream()
                .min(Comparator.comparingDouble(mob ->
                        mob.squaredDistanceTo(center.getX() + 0.5, center.getY(), center.getZ() + 0.5)))
                .get();
        Config.get().npcs.remove(nearest.getUuid().toString());
        Config.save();
        nearest.discard();
        return true;
    }

    /** Правый клик по сущности (UseEntityCallback). */
    public static ActionResult onUse(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hit) {
        NpcDef def = Config.get().npcs.get(entity.getUuid().toString());
        if (def == null) {
            return ActionResult.PASS;
        }
        if (!(player instanceof ServerPlayerEntity serverPlayer) || !(world instanceof ServerWorld serverWorld)) {
            return ActionResult.PASS;
        }
        if (hand != Hand.MAIN_HAND) {
            return ActionResult.SUCCESS;
        }
        long now = System.currentTimeMillis();
        String key = entity.getUuid() + ":" + player.getUuid();
        Long last = LAST_USE.get(key);
        if (def.cooldown > 0 && last != null && now - last < def.cooldown * 1000L) {
            long left = (def.cooldown * 1000L - (now - last) + 999) / 1000;
            serverPlayer.sendMessage(Text.literal("Подождите ещё " + left + " с"), true);
            return ActionResult.SUCCESS;
        }
        ItemStack stack = build(serverWorld.getServer(), def);
        if (stack.isEmpty()) {
            serverPlayer.sendMessage(Text.literal("У этого НПС не настроен предмет"), true);
            return ActionResult.SUCCESS;
        }
        serverPlayer.getInventory().offerOrDrop(stack);
        LAST_USE.put(key, now);
        serverPlayer.sendMessage(Text.literal("Вы получили: " + stack.getName().getString()), true);
        return ActionResult.SUCCESS;
    }

    public static ItemStack build(MinecraftServer server, NpcDef def) {
        Identifier id = Identifier.tryParse(def.item);
        if (id == null || !Registries.ITEM.containsId(id)) {
            return ItemStack.EMPTY;
        }
        Item item = Registries.ITEM.get(id);
        ItemStack stack = new ItemStack(item, Math.max(1, Math.min(def.count, item.getMaxCount())));

        Registry<Enchantment> registry = server.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        ItemEnchantmentsComponent.Builder builder = new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
        boolean any = false;
        for (RegistryEntry.Reference<Enchantment> entry : registry.streamEntries().toList()) {
            String enchantId = entry.getKey().map(k -> k.getValue().toString()).orElse("");
            Integer level = def.enchants.get(enchantId);
            if (level != null && level > 0) {
                builder.add(entry, level);
                any = true;
            }
        }
        if (any) {
            stack.set(stack.isOf(Items.ENCHANTED_BOOK)
                    ? DataComponentTypes.STORED_ENCHANTMENTS
                    : DataComponentTypes.ENCHANTMENTS, builder.build());
        }
        return stack;
    }
}
