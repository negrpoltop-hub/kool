package com.adminmod;

import com.adminmod.chaos.BombManager;
import com.adminmod.chaos.BombSettings;
import com.adminmod.chaos.DestroyManager;
import com.adminmod.chaos.DestroySettings;
import com.adminmod.chaos.MeteorManager;
import com.adminmod.chaos.MeteorSettings;
import com.adminmod.chaos.Profiles;
import com.adminmod.chaos.Targets;
import com.adminmod.npc.NpcDef;
import com.adminmod.npc.NpcManager;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.StreamSupport;

/**
 * Админ-панель: окно-сундук с иконками. Ничего нельзя забрать из окна напрямую —
 * клики по слотам обрабатываются как нажатия кнопок.
 */
public class PanelHandler extends GenericContainerScreenHandler {
    private static final int SIZE = 54;
    private static final int PER_PAGE = 45;

    private enum Mode { MAIN, ITEMS, MOBS, POTIONS, METEOR, BOMB, NPC, DESTROY, TOOLS, EXTRA, FUN }

    /** Состояние конструктора зелий для каждого админа. */
    private static final class Draft {
        final List<RegistryEntry<StatusEffect>> effects = new ArrayList<>();
        int level = 1;       // сила эффекта (1..255)
        int seconds = 180;   // длительность
        int type = 0;        // 0 обычное, 1 взрывное, 2 туманное
        boolean applyToMobs = false;
    }

    /** Состояние конструктора НПС-раздатчика. */
    private static final class NpcDraft {
        String item = "minecraft:diamond_sword";
        int count = 1;
        int cooldown = 0;
        int typeIndex = 0;
        final Map<String, Integer> enchants = new LinkedHashMap<>();
    }

    private static final List<EntityType<?>> NPC_TYPES = List.of(
            EntityType.VILLAGER, EntityType.WANDERING_TRADER, EntityType.IRON_GOLEM, EntityType.SNOW_GOLEM);
    private static final Map<UUID, NpcDraft> NPC_DRAFTS = new HashMap<>();

    private static final Map<UUID, Integer> LEVELS = new HashMap<>();
    private static final Map<UUID, Draft> DRAFTS = new HashMap<>();
    private static List<Item> allItems;
    private static List<EntityType<?>> allMobs;
    private static List<RegistryEntry.Reference<StatusEffect>> allEffects;

    private static final String[] TYPE_NAMES = {"обычное", "взрывное", "туманное"};

    private final SimpleInventory inv;
    private final MinecraftServer server;
    private ServerWorld world;
    private final UUID owner;
    private Mode mode = Mode.MAIN;
    private int page = 0;
    private int level; // уровень зачарования (0 = ванильный максимум)

    public PanelHandler(int syncId, PlayerInventory playerInventory, SimpleInventory inv,
                        MinecraftServer server, ServerWorld world) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInventory, inv, 6);
        this.inv = inv;
        this.server = server;
        this.world = world;
        this.owner = playerInventory.player.getUuid();
        this.level = LEVELS.getOrDefault(owner, Config.get().defaultEnchantLevel);
        showMain();
    }

    public static void open(ServerPlayerEntity player, MinecraftServer server, ServerWorld world) {
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInventory, p) ->
                        new PanelHandler(syncId, playerInventory, new SimpleInventory(SIZE), server, world),
                Text.literal("Админ-панель")));
    }

    // ---------- списки ----------

    private static List<Item> items() {
        if (allItems == null) {
            allItems = StreamSupport.stream(Registries.ITEM.spliterator(), false)
                    .filter(item -> item != Items.AIR)
                    .toList();
        }
        return allItems;
    }

    private static List<EntityType<?>> mobs() {
        if (allMobs == null) {
            List<EntityType<?>> list = new ArrayList<>();
            for (EntityType<?> type : Registries.ENTITY_TYPE) {
                if (type == EntityType.PLAYER || !type.isSummonable()) {
                    continue;
                }
                if (type.getSpawnGroup() != SpawnGroup.MISC || eggFor(type) != null) {
                    list.add(type);
                }
            }
            allMobs = list;
        }
        return allMobs;
    }

    private static List<RegistryEntry.Reference<StatusEffect>> effects() {
        if (allEffects == null) {
            allEffects = Registries.STATUS_EFFECT.streamEntries().toList();
        }
        return allEffects;
    }

    private static Item eggFor(EntityType<?> type) {
        Identifier id = Registries.ENTITY_TYPE.getId(type);
        Identifier egg = Identifier.of(id.getNamespace(), id.getPath() + "_spawn_egg");
        return Registries.ITEM.containsId(egg) ? Registries.ITEM.get(egg) : null;
    }

    private Draft draft() {
        return DRAFTS.computeIfAbsent(owner, key -> new Draft());
    }

    // ---------- иконки ----------

    private static ItemStack icon(Item item, String name) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name).styled(style -> style.withItalic(false)));
        return stack;
    }

    private static final String LORE_ADJ = "ЛКМ: +   ПКМ: −   шифт: ×10";

    /** Красивая иконка: цветное жирное имя с символом и серое описание. */
    private static ItemStack fancy(Item item, Formatting color, String symbol, String name, String... lore) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(symbol + " " + name)
                .styled(style -> style.withColor(color).withBold(true).withItalic(false)));
        if (lore.length > 0) {
            List<Text> lines = new ArrayList<>();
            for (String line : lore) {
                lines.add(Text.literal(line).styled(style -> style.withColor(Formatting.GRAY).withItalic(false)));
            }
            stack.set(DataComponentTypes.LORE, new LoreComponent(lines));
        }
        return stack;
    }

    private static ItemStack glint(ItemStack stack) {
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        return stack;
    }

    private void fillBackground() {
        ItemStack filler = icon(Items.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < SIZE; i++) {
            inv.setStack(i, filler.copy());
        }
    }

    // ---------- экраны ----------

    private String levelText() {
        return level == 0 ? "максимум (ванильный)" : String.valueOf(level);
    }

    private void setLevel(int value) {
        level = Math.max(0, Math.min(255, value));
        LEVELS.put(owner, level);
    }

    private void showMain() {
        mode = Mode.MAIN;
        fillBackground();
        // --- предметы ---
        inv.setStack(10, fancy(Items.CHEST, Formatting.GOLD, "▣", "Все предметы", "Каталог всех предметов игры"));
        inv.setStack(11, glint(fancy(Items.ENCHANTED_BOOK, Formatting.LIGHT_PURPLE, "✦", "Зачаровать предмет в руке", "Уровень: " + levelText())));
        inv.setStack(12, fancy(Items.ANVIL, Formatting.GRAY, "⚒", "Починить предмет в руке"));
        // --- игрок ---
        inv.setStack(13, glint(fancy(Items.NETHERITE_PICKAXE, Formatting.RED, "⛏", "Разрушить блоки (куда смотрите)",
                "Радиус: " + Profiles.destroy(owner).radius + ", форма: " + DestroySettings.SHAPES[Profiles.destroy(owner).shape])));
        inv.setStack(14, fancy(Items.GOLDEN_APPLE, Formatting.RED, "❤", "Вылечиться", "Полное здоровье"));
        inv.setStack(15, fancy(Items.COOKED_BEEF, Formatting.GOLD, "♨", "Накормить", "Полный голод и насыщение"));
        inv.setStack(16, fancy(Items.FEATHER, Formatting.WHITE, "✈", "Полёт: вкл/выкл", "Клик: переключить"));
        inv.setStack(19, fancy(Items.TOTEM_OF_UNDYING, Formatting.YELLOW, "☀", "Бессмертие: вкл/выкл", "Клик: переключить"));
        // --- уровень чар ---
        inv.setStack(20, glint(fancy(Items.FIREWORK_STAR, Formatting.LIGHT_PURPLE, "✦", "Развлечения",
                "Размер, скорость, дождь из животных, казнь мобов")));
        inv.setStack(21, fancy(Items.REDSTONE_TORCH, Formatting.RED, "−", "Уровень чар -1", "Шифт: -10"));
        inv.setStack(22, glint(fancy(Items.EXPERIENCE_BOTTLE, Formatting.GREEN, "✧", "Уровень чар: " + levelText(), "Клик: максимум")));
        inv.setStack(23, fancy(Items.TORCH, Formatting.GREEN, "+", "Уровень чар +1", "Шифт: +10"));
        // --- зелья, мобы, эффекты ---
        inv.setStack(28, fancy(Items.POTION, Formatting.LIGHT_PURPLE, "⚗", "Конструктор зелий", "Свои зелья из любых эффектов"));
        inv.setStack(29, fancy(Items.PIG_SPAWN_EGG, Formatting.GREEN, "☻", "Спавн мобов", "ЛКМ: 1, ПКМ: 5, шифт: 10"));
        inv.setStack(30, fancy(Items.ENDER_EYE, Formatting.DARK_AQUA, "◉", "Ночное зрение: вкл/выкл", "Клик: переключить"));
        inv.setStack(31, fancy(Items.SUGAR, Formatting.AQUA, "➤", "Скорость: вкл/выкл", "Клик: переключить"));
        inv.setStack(32, fancy(Items.LIGHTNING_ROD, Formatting.YELLOW, "⚡", "Молния перед собой", "Бьёт в 4 блоках перед вами"));
        inv.setStack(33, fancy(Items.IRON_SWORD, Formatting.RED, "⚔", "Убрать враждебных мобов", "Радиус 32 блока"));
        inv.setStack(34, fancy(Items.MILK_BUCKET, Formatting.WHITE, "✚", "Снять все эффекты"));
        // --- хаос ---
        inv.setStack(37, fancy(Items.REPEATER, Formatting.GOLD, "⚙", "Метеоритный дождь: настройки"));
        inv.setStack(38, glint(fancy(Items.FIRE_CHARGE, Formatting.RED, "☄", "Запустить метеоритный дождь", "Туда, куда вы смотрите")));
        inv.setStack(39, fancy(Items.COMPARATOR, Formatting.GOLD, "⚙", "Бомба из руки: настройки"));
        inv.setStack(40, glint(fancy(Items.BLAZE_ROD, Formatting.GOLD, "✹", "Выдать жезл бомб", "ПКМ с жезлом — бросок")));
        inv.setStack(42, fancy(Items.CRACKED_STONE_BRICKS, Formatting.RED, "⚒", "Разрушение и разлом: настройки",
                "Радиус, форма, радиус разлома, откат"));
        inv.setStack(43, glint(fancy(Items.NETHER_STAR, Formatting.AQUA, "✪", "Инструменты",
                "Телепорты, погода, эффекты, набор админа")));
        inv.setStack(44, glint(fancy(Items.ENDER_EYE, Formatting.LIGHT_PURPLE, "✧", "Ещё функции",
                "Стройка, охрана, мобы, копирование предметов")));
        // --- НПС ---
        inv.setStack(41, glint(fancy(Items.VILLAGER_SPAWN_EGG, Formatting.LIGHT_PURPLE, "☻", "НПС-раздатчик", "Выдаёт предметы с выбранными чарами")));
        inv.setStack(49, fancy(Items.BARRIER, Formatting.RED, "✖", "Закрыть"));
    }

    private static final String HINT = "  [ЛКМ +, ПКМ -, шифт x10]";

    private static String onOff(boolean value) {
        return value ? "ВКЛ" : "ВЫКЛ";
    }

    private static String num(double value) {
        double rounded = Math.round(value * 100.0) / 100.0;
        return rounded == Math.rint(rounded) ? String.valueOf((long) rounded) : String.valueOf(rounded);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static double clamp(double value, double min, double max) {
        return Math.round(Math.max(min, Math.min(max, value)) * 100.0) / 100.0;
    }

    private void showMeteor() {
        mode = Mode.METEOR;
        MeteorSettings m = Profiles.meteor(owner);
        fillBackground();
        inv.setStack(10, fancy(Items.FIRE_CHARGE, Formatting.GOLD, "☄", "Метеоритов: " + m.count, LORE_ADJ));
        inv.setStack(11, fancy(Items.COMPASS, Formatting.AQUA, "◎", "Радиус: " + m.radius, LORE_ADJ));
        inv.setStack(12, fancy(Items.ELYTRA, Formatting.WHITE, "⬆", "Высота: " + m.height, LORE_ADJ));
        inv.setStack(13, fancy(Items.TNT, Formatting.RED, "✹", "Сила взрыва: " + num(m.power), LORE_ADJ));
        inv.setStack(14, fancy(Items.FIREWORK_ROCKET, Formatting.AQUA, "➤", "Скорость падения: " + num(m.speed), LORE_ADJ));
        inv.setStack(15, fancy(Items.CLOCK, Formatting.YELLOW, "⌛", "Интервал, тики: " + m.interval, LORE_ADJ));
        inv.setStack(16, fancy(Items.FLINT_AND_STEEL, m.fire ? Formatting.GOLD : Formatting.DARK_GRAY, "♨", "Поджигать: " + onOff(m.fire), "Клик: переключить"));
        inv.setStack(19, fancy(Items.IRON_PICKAXE, m.breakBlocks ? Formatting.GREEN : Formatting.DARK_GRAY, "⛏", "Ломать блоки: " + onOff(m.breakBlocks), "Клик: переключить"));
        inv.setStack(22, glint(fancy(Items.BLAZE_POWDER, Formatting.GOLD, "☄", "ЗАПУСТИТЬ", "Падают туда, куда вы смотрите")));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "В меню"));
    }

    private void showBomb() {
        mode = Mode.BOMB;
        BombSettings b = Profiles.bomb(owner);
        fillBackground();
        inv.setStack(10, fancy(Items.TNT, Formatting.RED, "✹", "Сила взрыва: " + num(b.power), LORE_ADJ));
        inv.setStack(11, fancy(Items.FIREWORK_ROCKET, Formatting.AQUA, "➤", "Скорость полёта: " + num(b.speed), LORE_ADJ));
        inv.setStack(12, fancy(Items.ANVIL, Formatting.GRAY, "⬇", "Падение (гравитация): " + num(b.gravity), LORE_ADJ));
        inv.setStack(13, fancy(Items.ARROW, Formatting.YELLOW, "×", "Бомб за бросок: " + b.count, LORE_ADJ));
        inv.setStack(14, fancy(Items.STRING, Formatting.WHITE, "≈", "Разброс: " + num(b.spread), LORE_ADJ));
        inv.setStack(15, fancy(Items.CLOCK, Formatting.YELLOW, "⌛", "Перезарядка, тики: " + b.cooldown, LORE_ADJ));
        inv.setStack(16, fancy(Items.FLINT_AND_STEEL, b.fire ? Formatting.GOLD : Formatting.DARK_GRAY, "♨", "Поджигать: " + onOff(b.fire), "Клик: переключить"));
        inv.setStack(19, fancy(Items.IRON_PICKAXE, b.breakBlocks ? Formatting.GREEN : Formatting.DARK_GRAY, "⛏", "Ломать блоки: " + onOff(b.breakBlocks), "Клик: переключить"));
        inv.setStack(20, fancy(Items.BLAZE_ROD, b.enabled ? Formatting.GREEN : Formatting.DARK_GRAY, "⚡", "Жезл работает: " + onOff(b.enabled), "Клик: переключить"));
        inv.setStack(22, glint(fancy(Items.BLAZE_ROD, Formatting.GOLD, "✦", "Выдать жезл бомб", "ПКМ с жезлом — бросок")));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "В меню"));
    }

    private void showPager(int total, String title) {
        int pages = Math.max(1, (total + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        inv.setStack(48, fancy(Items.ARROW, Formatting.YELLOW, "◀", "Назад"));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "Меню — " + title + " (стр. " + (page + 1) + "/" + pages + ")", "Клик: вернуться в меню"));
        inv.setStack(50, fancy(Items.ARROW, Formatting.YELLOW, "▶", "Вперёд"));
    }

    private void showItems() {
        mode = Mode.ITEMS;
        List<Item> list = items();
        fillBackground();
        showPager(list.size(), "предметы");
        for (int i = 0; i < PER_PAGE; i++) {
            int index = page * PER_PAGE + i;
            inv.setStack(i, index < list.size() ? new ItemStack(list.get(index)) : ItemStack.EMPTY);
        }
    }

    private void showMobs() {
        mode = Mode.MOBS;
        List<EntityType<?>> list = mobs();
        fillBackground();
        showPager(list.size(), "мобы");
        for (int i = 0; i < PER_PAGE; i++) {
            int index = page * PER_PAGE + i;
            if (index < list.size()) {
                EntityType<?> type = list.get(index);
                Item egg = eggFor(type);
                inv.setStack(i, icon(egg != null ? egg : Items.NAME_TAG, type.getName().getString()));
            } else {
                inv.setStack(i, ItemStack.EMPTY);
            }
        }
        Draft d = draft();
        inv.setStack(46, icon(Items.ZOMBIE_HEAD, "Эффекты из конструктора на мобов: "
                + (d.applyToMobs ? "ВКЛ" : "ВЫКЛ") + " (" + d.effects.size() + " шт.)"));
    }

    private void showPotions() {
        mode = Mode.POTIONS;
        Draft d = draft();
        List<RegistryEntry.Reference<StatusEffect>> list = effects();
        fillBackground();
        for (int i = 0; i < PER_PAGE; i++) {
            if (i < list.size()) {
                RegistryEntry.Reference<StatusEffect> effect = list.get(i);
                boolean selected = d.effects.contains(effect);
                String name = effect.value().getName().getString();
                ItemStack stack = icon(Items.POTION, (selected ? "✔ " : "") + name);
                inv.setStack(i, selected ? glint(stack) : stack);
            } else {
                inv.setStack(i, ItemStack.EMPTY);
            }
        }
        Item typeItem = d.type == 1 ? Items.SPLASH_POTION : d.type == 2 ? Items.LINGERING_POTION : Items.POTION;
        inv.setStack(45, fancy(Items.REDSTONE_TORCH, Formatting.RED, "−", "Сила -1 (сейчас " + d.level + ")", "Шифт: -10"));
        inv.setStack(46, fancy(Items.TORCH, Formatting.GREEN, "+", "Сила +1 (сейчас " + d.level + ")", "Шифт: +10"));
        inv.setStack(47, fancy(Items.CLOCK, Formatting.RED, "−", "Время -30 с (сейчас " + d.seconds + " с)", "Шифт: -300 с"));
        inv.setStack(48, fancy(Items.CLOCK, Formatting.GREEN, "+", "Время +30 с (сейчас " + d.seconds + " с)", "Шифт: +300 с"));
        inv.setStack(49, fancy(typeItem, Formatting.LIGHT_PURPLE, "⚗", "Тип: " + TYPE_NAMES[d.type], "Клик: сменить тип"));
        inv.setStack(50, glint(fancy(Items.BREWING_STAND, Formatting.GOLD, "✦", "Выдать зелье (эффектов: " + d.effects.size() + ")")));
        inv.setStack(51, fancy(Items.BUCKET, Formatting.GRAY, "↺", "Очистить выбор"));
        inv.setStack(52, fancy(Items.ZOMBIE_HEAD, d.applyToMobs ? Formatting.GREEN : Formatting.DARK_GRAY, "☠", "Эффекты на мобов: " + onOff(d.applyToMobs), "Клик: переключить"));
        inv.setStack(53, fancy(Items.ARROW, Formatting.AQUA, "↩", "В меню"));
    }

    private ItemStack buildPotion(Draft d) {
        Item base = d.type == 1 ? Items.SPLASH_POTION : d.type == 2 ? Items.LINGERING_POTION : Items.POTION;
        ItemStack stack = new ItemStack(base);
        PotionContentsComponent contents = PotionContentsComponent.DEFAULT;
        for (RegistryEntry<StatusEffect> effect : d.effects) {
            contents = contents.with(new StatusEffectInstance(effect, d.seconds * 20, d.level - 1));
        }
        stack.set(DataComponentTypes.POTION_CONTENTS, contents);
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal("Зелье админа").styled(style -> style.withItalic(false)));
        return stack;
    }

    // ---------- клики ----------

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < SIZE) {
            if (player instanceof ServerPlayerEntity serverPlayer) {
                handleClick(slotIndex, button, actionType, serverPlayer);
            }
            syncState();
            return;
        }
        if (actionType == SlotActionType.QUICK_MOVE
                || actionType == SlotActionType.QUICK_CRAFT
                || actionType == SlotActionType.PICKUP_ALL) {
            syncState();
            return;
        }
        super.onSlotClick(slotIndex, button, actionType, player);
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    private void handleClick(int slot, int button, SlotActionType type, ServerPlayerEntity player) {
        // права могли быть отозваны, пока панель открыта
        if (!Config.isAdmin(player)) {
            player.closeHandledScreen();
            return;
        }
        // игрок мог сменить измерение с открытой панелью
        ServerWorld current = Tools.worldOf(server, player);
        if (current != null) {
            world = current;
        }
        boolean shift = type == SlotActionType.QUICK_MOVE;
        switch (mode) {
            case MAIN -> clickMain(slot, shift, player);
            case ITEMS -> clickItems(slot, button, shift, player);
            case MOBS -> clickMobs(slot, button, shift, player);
            case POTIONS -> clickPotions(slot, shift, player);
            case METEOR -> clickMeteor(slot, button, shift, player);
            case BOMB -> clickBomb(slot, button, shift, player);
            case NPC -> clickNpc(slot, button, shift, player);
            case DESTROY -> clickDestroy(slot, button, shift, player);
            case TOOLS -> clickTools(slot, button, shift, player);
            case EXTRA -> clickExtra(slot, player);
            case FUN -> clickFun(slot, player);
        }
    }

    private void clickMain(int slot, boolean shift, ServerPlayerEntity player) {
        switch (slot) {
            case 10 -> {
                page = 0;
                showItems();
            }
            case 11 -> {
                ItemStack held = player.getMainHandStack();
                if (held.isEmpty()) {
                    message(player, "Возьмите предмет в руку");
                } else {
                    int count = Actions.enchantMax(server, held, level);
                    message(player, "Наложено зачарований: " + count + ", уровень: " + levelText());
                }
            }
            case 12 -> message(player, Actions.repair(player.getMainHandStack())
                    ? "Предмет починен" : "Этот предмет нельзя починить");
            case 13 -> {
                int count = DestroyManager.blast(player, world, Profiles.destroy(owner));
                message(player, count < 0 ? "Очередь разрушения полна" : "Разрушаю область, позиций: " + count);
            }
            case 14 -> {
                Actions.heal(player);
                message(player, "Здоровье восстановлено");
            }
            case 15 -> {
                Actions.feed(player);
                message(player, "Голод утолён");
            }
            case 16 -> message(player, Actions.toggleFly(player) ? "Полёт включён" : "Полёт выключен");
            case 19 -> message(player, Actions.toggleGod(player) ? "Бессмертие включено" : "Бессмертие выключено");
            case 21 -> {
                setLevel(level - (shift ? 10 : 1));
                showMain();
            }
            case 23 -> {
                setLevel(level + (shift ? 10 : 1));
                showMain();
            }
            case 22 -> {
                setLevel(0);
                showMain();
            }
            case 28 -> showPotions();
            case 29 -> {
                page = 0;
                showMobs();
            }
            case 30 -> message(player, Actions.toggleEffect(player, StatusEffects.NIGHT_VISION, 0)
                    ? "Ночное зрение включено" : "Ночное зрение выключено");
            case 31 -> message(player, Actions.toggleEffect(player, StatusEffects.SPEED, 2)
                    ? "Скорость включена" : "Скорость выключена");
            case 32 -> Actions.smite(world, player);
            case 33 -> message(player, "Убрано мобов: " + Actions.clearMobs(world, player));
            case 34 -> {
                Actions.clearEffects(player);
                message(player, "Эффекты сняты");
            }
            case 37 -> showMeteor();
            case 38 -> {
                MeteorManager.start(world, Targets.look(player), Profiles.meteor(owner));
                message(player, "Метеоритный дождь запущен");
            }
            case 39 -> showBomb();
            case 40 -> {
                BombManager.giveWand(player);
                message(player, "Жезл бомб выдан: правый клик запускает бомбу");
            }
            case 41 -> {
                ItemStack held = player.getMainHandStack();
                if (!held.isEmpty()) {
                    takeHeldItem(held, npcDraft());
                }
                showNpc();
            }
            case 42 -> showDestroy();
            case 43 -> showTools();
            case 44 -> showExtra();
            case 20 -> showFun();
            case 49 -> player.closeHandledScreen();
            default -> {
            }
        }
    }

    private void clickMeteor(int slot, int button, boolean shift, ServerPlayerEntity player) {
        MeteorSettings m = Profiles.meteor(owner);
        int dir = button == 1 ? -1 : 1;
        int mul = shift ? 10 : 1;
        switch (slot) {
            case 10 -> m.count = clamp(m.count + dir * mul, 1, 500);
            case 11 -> m.radius = clamp(m.radius + dir * mul, 1, 48);
            case 12 -> m.height = clamp(m.height + dir * mul * 5, 10, 120);
            case 13 -> m.power = clamp(m.power + dir * mul * 0.5, 0.5, 20.0);
            case 14 -> m.speed = clamp(m.speed + dir * mul * 0.25, 0.25, 4.0);
            case 15 -> m.interval = clamp(m.interval + dir * mul, 1, 100);
            case 16 -> m.fire = !m.fire;
            case 19 -> m.breakBlocks = !m.breakBlocks;
            case 22 -> {
                MeteorManager.start(world, Targets.look(player), m);
                message(player, "Метеоритный дождь запущен");
                return;
            }
            case 49 -> {
                showMain();
                return;
            }
            default -> {
                return;
            }
        }
        showMeteor();
    }

    private void clickBomb(int slot, int button, boolean shift, ServerPlayerEntity player) {
        BombSettings b = Profiles.bomb(owner);
        int dir = button == 1 ? -1 : 1;
        int mul = shift ? 10 : 1;
        switch (slot) {
            case 10 -> b.power = clamp(b.power + dir * mul * 0.5, 0.5, 20.0);
            case 11 -> b.speed = clamp(b.speed + dir * mul * 0.25, 0.25, 5.0);
            case 12 -> b.gravity = clamp(b.gravity + dir * mul * 0.01, 0.0, 0.2);
            case 13 -> b.count = clamp(b.count + dir * mul, 1, 20);
            case 14 -> b.spread = clamp(b.spread + dir * mul * 0.02, 0.0, 0.5);
            case 15 -> b.cooldown = clamp(b.cooldown + dir * mul * 5, 0, 200);
            case 16 -> b.fire = !b.fire;
            case 19 -> b.breakBlocks = !b.breakBlocks;
            case 20 -> b.enabled = !b.enabled;
            case 22 -> {
                BombManager.giveWand(player);
                message(player, "Жезл бомб выдан: правый клик запускает бомбу");
                return;
            }
            case 49 -> {
                showMain();
                return;
            }
            default -> {
                return;
            }
        }
        showBomb();
    }

    // ---------- разрушение и разлом ----------

    private void showDestroy() {
        mode = Mode.DESTROY;
        DestroySettings d = Profiles.destroy(owner);
        fillBackground();
        Item shapeItem = d.shape == 0 ? Items.ENDER_PEARL : d.shape == 1 ? Items.STONE : Items.BARREL;
        inv.setStack(10, fancy(Items.TNT, Formatting.RED, "◎", "Радиус разрушения: " + d.radius, LORE_ADJ));
        inv.setStack(11, fancy(shapeItem, Formatting.LIGHT_PURPLE, "◈", "Форма: " + DestroySettings.SHAPES[d.shape], "Клик: сменить форму"));
        inv.setStack(12, fancy(Items.CRACKED_STONE_BRICKS, Formatting.GOLD, "◎", "Радиус разлома: " + d.riftRadius, LORE_ADJ));
        inv.setStack(13, fancy(Items.ARROW, Formatting.YELLOW, "↔", "Длина разлома: " + d.riftLength, LORE_ADJ));
        inv.setStack(14, fancy(Items.DEEPSLATE, Formatting.DARK_GRAY, "⬇", "Глубина разлома: " + d.riftDepth, LORE_ADJ));
        inv.setStack(15, fancy(Items.HOPPER, d.drops ? Formatting.GREEN : Formatting.DARK_GRAY, "◆", "Выпадение предметов: " + onOff(d.drops), "Клик: переключить"));
        inv.setStack(16, fancy(Items.WATER_BUCKET, d.fluids ? Formatting.AQUA : Formatting.DARK_GRAY, "≈", "Убирать воду и лаву: " + onOff(d.fluids), "Клик: переключить"));
        inv.setStack(19, fancy(Items.BEDROCK, d.bedrock ? Formatting.RED : Formatting.DARK_GRAY, "✖", "Ломать бедрок: " + onOff(d.bedrock), "Клик: переключить"));
        inv.setStack(21, glint(fancy(Items.NETHERITE_PICKAXE, Formatting.RED, "⛏", "РАЗРУШИТЬ (куда смотрите)", "Шар/куб/цилиндр вокруг точки прицела")));
        inv.setStack(22, glint(fancy(Items.NETHERITE_SHOVEL, Formatting.GOLD, "⚒", "РАЗЛОМ вперёд от вас", "Неровная трещина по ходу взгляда")));
        inv.setStack(23, fancy(Items.CLOCK, Formatting.GREEN, "↺", "ОТКАТИТЬ последнее разрушение", "Вернёт блоки (до 400 000)"));
        inv.setStack(24, fancy(Items.BARRIER, Formatting.RED, "✖", "Отменить текущее разрушение"));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "В меню"));
    }

    private void clickDestroy(int slot, int button, boolean shift, ServerPlayerEntity player) {
        DestroySettings d = Profiles.destroy(owner);
        int dir = button == 1 ? -1 : 1;
        int mul = shift ? 10 : 1;
        switch (slot) {
            case 10 -> d.radius = clamp(d.radius + dir * mul, 1, 32);
            case 11 -> d.shape = (d.shape + 1) % DestroySettings.SHAPES.length;
            case 12 -> d.riftRadius = clamp(d.riftRadius + dir * mul, 1, 16);
            case 13 -> d.riftLength = clamp(d.riftLength + dir * mul * 5, 5, 128);
            case 14 -> d.riftDepth = clamp(d.riftDepth + dir * mul * 2, 3, 64);
            case 15 -> d.drops = !d.drops;
            case 16 -> d.fluids = !d.fluids;
            case 19 -> d.bedrock = !d.bedrock;
            case 21 -> {
                int count = DestroyManager.blast(player, world, d);
                message(player, count < 0 ? "Очередь разрушения полна" : "Разрушаю область, позиций: " + count);
                return;
            }
            case 22 -> {
                int count = DestroyManager.rift(player, world, d);
                message(player, count < 0 ? "Очередь разрушения полна" : "Открываю разлом, позиций: " + count);
                return;
            }
            case 23 -> {
                int count = DestroyManager.undo(owner);
                message(player, count > 0 ? "Возвращаю блоков: " + count : "Откатывать нечего");
                return;
            }
            case 24 -> {
                message(player, "Отменено задач: " + DestroyManager.cancel(owner));
                return;
            }
            case 49 -> {
                showMain();
                return;
            }
            default -> {
                return;
            }
        }
        showDestroy();
    }

    // ---------- инструменты ----------

    private void showTools() {
        mode = Mode.TOOLS;
        fillBackground();
        int fly = Profiles.tools(owner).flySpeed;
        // перемещение
        inv.setStack(10, fancy(Items.FEATHER, Formatting.WHITE, "✈", "Скорость полёта: " + fly + "/10", LORE_ADJ));
        inv.setStack(11, fancy(Items.GRASS_BLOCK, Formatting.GREEN, "◈", "Режим игры: сменить", "Выживание → креатив → наблюдатель → приключение"));
        inv.setStack(12, fancy(Items.ENDER_PEARL, Formatting.DARK_AQUA, "➤", "Телепорт к прицелу", "На блок, на который вы смотрите"));
        inv.setStack(13, fancy(Items.LADDER, Formatting.YELLOW, "⬆", "Наверх, на поверхность"));
        inv.setStack(14, fancy(Items.RECOVERY_COMPASS, Formatting.AQUA, "↩", "Вернуться назад", "На место перед последним телепортом"));
        inv.setStack(15, fancy(Items.ENDER_CHEST, Formatting.DARK_PURPLE, "▣", "Эндер-сундук везде"));
        inv.setStack(16, glint(fancy(Items.NETHERITE_CHESTPLATE, Formatting.GOLD, "✦", "Набор админа", "Зачарованное незеритовое снаряжение")));
        // погода и время
        inv.setStack(19, fancy(Items.SUNFLOWER, Formatting.YELLOW, "☀", "День"));
        inv.setStack(20, fancy(Items.BLACK_WOOL, Formatting.DARK_GRAY, "☾", "Ночь"));
        inv.setStack(21, fancy(Items.WHITE_STAINED_GLASS, Formatting.WHITE, "☀", "Ясная погода"));
        inv.setStack(22, fancy(Items.WATER_BUCKET, Formatting.AQUA, "☂", "Дождь"));
        inv.setStack(23, fancy(Items.LIGHTNING_ROD, Formatting.YELLOW, "⚡", "Гроза"));
        inv.setStack(24, fancy(Items.COPPER_BLOCK, Formatting.GOLD, "⚡", "Грозовой шторм", "14 молний вокруг прицела"));
        inv.setStack(25, glint(fancy(Items.TNT, Formatting.RED, "✹", "Мега-взрыв в точке прицела", "Сила 10, ломает блоки")));
        // эффекты
        inv.setStack(28, fancy(Items.RABBIT_FOOT, Formatting.GREEN, "⬆", "Суперпрыжок: вкл/выкл", "Клик: переключить"));
        inv.setStack(29, fancy(Items.PUFFERFISH, Formatting.AQUA, "≈", "Дыхание под водой: вкл/выкл", "Клик: переключить"));
        inv.setStack(30, fancy(Items.MAGMA_CREAM, Formatting.GOLD, "♨", "Огнестойкость: вкл/выкл", "Клик: переключить"));
        inv.setStack(31, fancy(Items.GOLDEN_PICKAXE, Formatting.YELLOW, "⛏", "Быстрая добыча: вкл/выкл", "Клик: переключить"));
        inv.setStack(32, fancy(Items.BLAZE_POWDER, Formatting.RED, "⚔", "Сила: вкл/выкл", "Клик: переключить"));
        inv.setStack(33, fancy(Items.GHAST_TEAR, Formatting.LIGHT_PURPLE, "❤", "Регенерация: вкл/выкл", "Клик: переключить"));
        inv.setStack(34, fancy(Items.SHIELD, Formatting.GRAY, "◆", "Сопротивление урону: вкл/выкл", "Клик: переключить"));
        // разное
        inv.setStack(37, fancy(Items.GLASS, Formatting.WHITE, "◌", "Невидимость: вкл/выкл", "Клик: переключить"));
        inv.setStack(38, fancy(Items.GLOWSTONE_DUST, Formatting.YELLOW, "✧", "Свечение: вкл/выкл", "Клик: переключить"));
        inv.setStack(39, fancy(Items.EXPERIENCE_BOTTLE, Formatting.GREEN, "✧", "Опыт: +10 уровней", "Шифт: +100 уровней"));
        inv.setStack(40, fancy(Items.ENCHANTED_GOLDEN_APPLE, Formatting.RED, "❤", "Вылечить и накормить всех игроков"));
        inv.setStack(41, fancy(Items.LAVA_BUCKET, Formatting.RED, "✖", "Убрать предметы с земли", "Радиус 64 блока"));
        inv.setStack(42, fancy(Items.IRON_INGOT, Formatting.GRAY, "⇄", "Притянуть предметы к себе", "Радиус 24 блока"));
        inv.setStack(43, fancy(Items.PACKED_ICE, Formatting.AQUA, "❄", "Заморозить мобов рядом", "Радиус 32, мобы перестанут двигаться"));
        inv.setStack(44, fancy(Items.BLAZE_ROD, Formatting.GOLD, "♨", "Разморозить мобов рядом"));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "В меню"));
    }

    private void clickTools(int slot, int button, boolean shift, ServerPlayerEntity player) {
        switch (slot) {
            case 10 -> {
                int dir = button == 1 ? -1 : 1;
                var t = Profiles.tools(owner);
                t.flySpeed = clamp(t.flySpeed + dir * (shift ? 3 : 1), 1, 10);
                Tools.setFlySpeed(player, t.flySpeed);
                showTools();
            }
            case 11 -> message(player, "Режим игры: " + Tools.cycleGameMode(player));
            case 12 -> message(player, Tools.teleportToTarget(player) ? "Телепорт к прицелу" : "Смотрите на блок");
            case 13 -> {
                Tools.teleportToSurface(world, player);
                message(player, "Вы на поверхности");
            }
            case 14 -> message(player, Tools.teleportBack(player) ? "Вы вернулись" : "Некуда возвращаться");
            case 15 -> Tools.openEnderChest(player);
            case 16 -> message(player, "Выдано предметов: " + Tools.giveKit(server, player, level));
            case 19 -> {
                Tools.run(server, "time set day");
                message(player, "День");
            }
            case 20 -> {
                Tools.run(server, "time set night");
                message(player, "Ночь");
            }
            case 21 -> {
                Tools.run(server, "weather clear");
                message(player, "Ясная погода");
            }
            case 22 -> {
                Tools.run(server, "weather rain");
                message(player, "Дождь");
            }
            case 23 -> {
                Tools.run(server, "weather thunder");
                message(player, "Гроза");
            }
            case 24 -> {
                Tools.lightningStorm(world, player);
                message(player, "Грозовой шторм!");
            }
            case 25 -> {
                Tools.megaExplosion(world, player);
                message(player, "Взрыв!");
            }
            case 28 -> message(player, effectText(player, StatusEffects.JUMP_BOOST, 4, "Суперпрыжок"));
            case 29 -> message(player, effectText(player, StatusEffects.WATER_BREATHING, 0, "Дыхание под водой"));
            case 30 -> message(player, effectText(player, StatusEffects.FIRE_RESISTANCE, 0, "Огнестойкость"));
            case 31 -> message(player, effectText(player, StatusEffects.HASTE, 4, "Быстрая добыча"));
            case 32 -> message(player, effectText(player, StatusEffects.STRENGTH, 4, "Сила"));
            case 33 -> message(player, effectText(player, StatusEffects.REGENERATION, 2, "Регенерация"));
            case 34 -> message(player, effectText(player, StatusEffects.RESISTANCE, 4, "Сопротивление урону"));
            case 37 -> message(player, effectText(player, StatusEffects.INVISIBILITY, 0, "Невидимость"));
            case 38 -> message(player, effectText(player, StatusEffects.GLOWING, 0, "Свечение"));
            case 39 -> {
                player.addExperienceLevels(shift ? 100 : 10);
                message(player, "Опыт добавлен");
            }
            case 40 -> message(player, "Вылечено игроков: " + Tools.healAll(server));
            case 41 -> message(player, "Убрано предметов: " + Tools.clearItems(world, player));
            case 42 -> message(player, "Притянуто предметов: " + Tools.magnet(world, player));
            case 43 -> message(player, "Заморожено мобов: " + Tools.freezeMobs(world, player, true));
            case 44 -> message(player, "Разморожено мобов: " + Tools.freezeMobs(world, player, false));
            case 49 -> showMain();
            default -> {
            }
        }
    }

    private static String effectText(ServerPlayerEntity player, RegistryEntry<StatusEffect> effect, int amplifier, String name) {
        return name + (Actions.toggleEffect(player, effect, amplifier) ? " включено" : " выключено");
    }

    // ---------- ещё функции ----------

    private void showExtra() {
        mode = Mode.EXTRA;
        fillBackground();
        // стройка
        inv.setStack(10, fancy(Items.STONE_BRICKS, Formatting.GRAY, "▦", "Платформа под ногами", "Каменная, 11x11 блоков"));
        inv.setStack(11, fancy(Items.GLASS, Formatting.AQUA, "▣", "Бункер вокруг вас", "Комната 7x7: стекло, камень, лампа"));
        inv.setStack(12, fancy(Items.SCAFFOLDING, Formatting.YELLOW, "⚒", "Набор строителя", "Блоки, лестницы, леса, вода"));
        // охрана и мобы
        inv.setStack(13, fancy(Items.IRON_GOLEM_SPAWN_EGG, Formatting.WHITE, "☻", "Призвать охрану", "4 железных голема вокруг вас"));
        inv.setStack(14, fancy(Items.RED_DYE, Formatting.RED, "✖", "Убрать ВСЕХ мобов рядом", "Радиус 48, НПС не трогает"));
        inv.setStack(15, fancy(Items.GLOWSTONE_DUST, Formatting.YELLOW, "✧", "Подсветить мобов", "Радиус 48, на 1 минуту"));
        inv.setStack(16, fancy(Items.SHULKER_SHELL, Formatting.LIGHT_PURPLE, "⬆", "Подбросить мобов", "Левитация на 5 секунд, радиус 32"));
        // предметы
        inv.setStack(19, glint(fancy(Items.GOLD_INGOT, Formatting.GOLD, "◆", "Копировать предмет в руке", "Полный стак в инвентарь")));
        inv.setStack(20, fancy(Items.ANVIL, Formatting.GRAY, "⚒", "Починить всё в инвентаре"));
        // игроки и мобы
        inv.setStack(21, fancy(Items.ENDER_PEARL, Formatting.DARK_AQUA, "➤", "Телепортировать всех ко мне", "Все игроки онлайн"));
        inv.setStack(22, fancy(Items.GOLDEN_APPLE, Formatting.RED, "❤", "Вылечить мобов рядом", "Радиус 32"));
        inv.setStack(23, fancy(Items.MAP, Formatting.GREEN, "⌖", "Мои координаты", "Покажет в чате"));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "В меню"));
    }

    private void clickExtra(int slot, ServerPlayerEntity player) {
        switch (slot) {
            case 10 -> message(player, "Платформа построена, блоков: " + Tools.buildPlatform(world, player));
            case 11 -> message(player, "Бункер построен, блоков изменено: " + Tools.buildBunker(world, player));
            case 12 -> message(player, "Выдан набор строителя: " + Tools.giveBuilderKit(player) + " видов");
            case 13 -> message(player, "Призвано охранников: " + Tools.summonGuards(world, player));
            case 14 -> message(player, "Убрано мобов: " + Tools.killAllMobs(world, player));
            case 15 -> message(player, "Подсвечено мобов: " + Tools.glowMobs(world, player));
            case 16 -> message(player, "Подброшено мобов: " + Tools.launchMobs(world, player));
            case 19 -> message(player, Tools.duplicateHeld(player) ? "Предмет скопирован" : "Возьмите предмет в руку");
            case 20 -> message(player, "Починено предметов: " + Tools.repairAll(player));
            case 21 -> {
                Tools.bringAll(server, player);
                message(player, "Все игроки телепортированы к вам");
            }
            case 22 -> message(player, "Вылечено мобов: " + Tools.healMobs(world, player));
            case 23 -> player.sendMessage(Text.literal(Tools.coords(player)), false);
            case 49 -> showMain();
            default -> {
            }
        }
    }

    // ---------- развлечения ----------

    private long clearInventoryArmedAt = 0;

    private void showFun() {
        mode = Mode.FUN;
        fillBackground();
        var t = Profiles.tools(owner);
        inv.setStack(10, fancy(Items.SLIME_BALL, Formatting.GREEN, "⇕", "Размер: x" + Tools.num(Tools.SIZES[t.size]), "Клик: сменить размер (0.25 – 4)"));
        inv.setStack(11, fancy(Items.LEATHER_BOOTS, Formatting.AQUA, "➤", "Скорость ходьбы: x" + Tools.WALK[t.walk], "Клик: сменить (x1 – x8)"));
        inv.setStack(12, fancy(Items.GLISTERING_MELON_SLICE, Formatting.RED, "❤", "Максимум здоровья: " + Tools.HEALTH[t.health], "Клик: сменить (20 – 200)"));
        inv.setStack(13, fancy(Items.PHANTOM_MEMBRANE, Formatting.LIGHT_PURPLE, "⬆", "Гравитация: " + Tools.GRAVITY_NAMES[t.gravity], "Клик: сменить"));
        inv.setStack(14, fancy(Items.MILK_BUCKET, Formatting.WHITE, "↺", "Сбросить всё к обычному", "Размер, скорость, здоровье, гравитация"));
        inv.setStack(15, fancy(Items.LODESTONE, Formatting.YELLOW, "⌖", "Сохранить точку", "Запомнит ваше место"));
        inv.setStack(16, fancy(Items.RESPAWN_ANCHOR, Formatting.DARK_PURPLE, "➤", "Телепорт на сохранённую точку"));
        inv.setStack(19, fancy(Items.EGG, Formatting.YELLOW, "☁", "Дождь из животных", "20 животных падают на точку прицела"));
        inv.setStack(20, fancy(Items.TRIDENT, Formatting.YELLOW, "⚡", "Казнь молнией", "Молния в каждого враждебного моба (32 блока)"));
        inv.setStack(21, fancy(Items.FIRE_CHARGE, Formatting.RED, "✹", "Бомбардировка мобов", "Взрыв под каждым врагом. Урон и вам, если рядом!"));
        inv.setStack(22, fancy(Items.FLINT_AND_STEEL, Formatting.GOLD, "♨", "Поджечь мобов рядом", "Радиус 32, на 10 секунд"));
        inv.setStack(23, fancy(Items.LEAD, Formatting.GRAY, "⇄", "Притянуть мобов к себе", "Радиус 32"));
        inv.setStack(24, fancy(Items.CHEST, Formatting.GOLD, "◆", "Раздать предмет из руки всем", "Копия каждому игроку онлайн"));
        inv.setStack(25, fancy(Items.LAVA_BUCKET, Formatting.RED, "✖", "Очистить инвентарь", "Нажмите дважды за 5 секунд"));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "В меню"));
    }

    private void clickFun(int slot, ServerPlayerEntity player) {
        var t = Profiles.tools(owner);
        switch (slot) {
            case 10 -> {
                Tools.nextSize(player, t);
                showFun();
            }
            case 11 -> {
                Tools.nextWalk(player, t);
                showFun();
            }
            case 12 -> {
                Tools.nextHealth(player, t);
                showFun();
            }
            case 13 -> {
                Tools.nextGravity(player, t);
                showFun();
            }
            case 14 -> {
                Tools.resetAttributes(player, t);
                showFun();
                message(player, "Всё сброшено к обычному");
            }
            case 15 -> {
                Tools.setPoint(player);
                message(player, "Точка сохранена");
            }
            case 16 -> message(player, Tools.goPoint(player) ? "Телепорт на точку" : "Сначала сохраните точку");
            case 19 -> message(player, "Упало животных: " + Tools.animalRain(world, player));
            case 20 -> message(player, "Поражено мобов: " + Tools.smiteMobs(world, player));
            case 21 -> message(player, "Взорвано мобов: " + Tools.bombMobs(world, player));
            case 22 -> message(player, "Подожжено мобов: " + Tools.burnMobs(world, player));
            case 23 -> message(player, "Притянуто мобов: " + Tools.pullMobs(world, player));
            case 24 -> {
                int count = Tools.giveAll(server, player);
                message(player, count < 0 ? "Возьмите предмет в руку" : "Предмет выдан игрокам: " + count);
            }
            case 25 -> {
                long now = System.currentTimeMillis();
                if (now - clearInventoryArmedAt < 5000) {
                    player.getInventory().clear();
                    clearInventoryArmedAt = 0;
                    message(player, "Инвентарь очищен");
                } else {
                    clearInventoryArmedAt = now;
                    message(player, "Нажмите ещё раз, чтобы очистить инвентарь");
                }
            }
            case 49 -> showMain();
            default -> {
            }
        }
    }

    // ---------- НПС-раздатчик ----------

    private NpcDraft npcDraft() {
        return NPC_DRAFTS.computeIfAbsent(owner, key -> new NpcDraft());
    }

    private static void takeHeldItem(ItemStack held, NpcDraft draft) {
        Item item = held.isOf(Items.BOOK) ? Items.ENCHANTED_BOOK : held.getItem();
        draft.item = Registries.ITEM.getId(item).toString();
        draft.enchants.clear();
    }

    private static String enchantId(RegistryEntry.Reference<Enchantment> entry) {
        return entry.getKey().map(key -> key.getValue().toString()).orElse("");
    }

    private Item npcItem(NpcDraft draft) {
        Identifier id = Identifier.tryParse(draft.item);
        return id != null && Registries.ITEM.containsId(id) ? Registries.ITEM.get(id) : Items.DIAMOND_SWORD;
    }

    /** Зачарования, подходящие выбранному предмету (для книги — все). */
    private List<RegistryEntry.Reference<Enchantment>> npcEnchants(NpcDraft draft) {
        Registry<Enchantment> registry = server.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        Item item = npcItem(draft);
        ItemStack probe = new ItemStack(item);
        List<RegistryEntry.Reference<Enchantment>> result = new ArrayList<>();
        for (RegistryEntry.Reference<Enchantment> entry : registry.streamEntries().toList()) {
            if (item == Items.ENCHANTED_BOOK || entry.value().isAcceptableItem(probe)) {
                result.add(entry);
            }
        }
        return result;
    }

    private void showNpc() {
        mode = Mode.NPC;
        NpcDraft d = npcDraft();
        fillBackground();
        List<RegistryEntry.Reference<Enchantment>> list = npcEnchants(d);
        for (int i = 0; i < PER_PAGE; i++) {
            if (i < list.size()) {
                RegistryEntry.Reference<Enchantment> entry = list.get(i);
                int lvl = d.enchants.getOrDefault(enchantId(entry), 0);
                String name = entry.value().description().getString();
                String text = (lvl > 0 ? "✔ " : "") + name + ": " + (lvl > 0 ? String.valueOf(lvl) : "не выбрано")
                        + " (ванильный макс. " + entry.value().getMaxLevel() + ")" + HINT;
                ItemStack stack = icon(lvl > 0 ? Items.ENCHANTED_BOOK : Items.BOOK, text);
                inv.setStack(i, lvl > 0 ? glint(stack) : stack);
            } else {
                inv.setStack(i, ItemStack.EMPTY);
            }
        }
        Item item = npcItem(d);
        String itemName = new ItemStack(item).getName().getString();
        EntityType<?> type = NPC_TYPES.get(d.typeIndex);
        Item egg = eggFor(type);
        inv.setStack(45, fancy(item, Formatting.GOLD, "◆", "Предмет: " + itemName, "Клик: взять предмет из руки"));
        inv.setStack(46, fancy(Items.PAPER, Formatting.WHITE, "#", "Количество: " + d.count, LORE_ADJ));
        inv.setStack(47, fancy(Items.CLOCK, Formatting.YELLOW, "⌛", "Перезарядка: " + d.cooldown + " с (0 = нет)", LORE_ADJ));
        inv.setStack(48, fancy(egg != null ? egg : Items.NAME_TAG, Formatting.LIGHT_PURPLE, "☻", "Вид НПС: " + type.getName().getString(), "Клик: сменить вид"));
        inv.setStack(49, fancy(Items.COMPASS, Formatting.AQUA, "↩", "В меню"));
        inv.setStack(50, glint(fancy(Items.VILLAGER_SPAWN_EGG, Formatting.GREEN, "✚", "СОЗДАТЬ НПС перед собой", "Появится в 2 блоках перед вами")));
        inv.setStack(51, fancy(Items.LAVA_BUCKET, Formatting.RED, "✖", "Удалить ближайшего НПС", "Радиус 6 блоков"));
        inv.setStack(52, fancy(Items.BUCKET, Formatting.GRAY, "↺", "Сбросить выбранные чары"));
    }

    private void clickNpc(int slot, int button, boolean shift, ServerPlayerEntity player) {
        NpcDraft d = npcDraft();
        int dir = button == 1 ? -1 : 1;
        int mul = shift ? 10 : 1;
        if (slot < PER_PAGE) {
            List<RegistryEntry.Reference<Enchantment>> list = npcEnchants(d);
            if (slot < list.size()) {
                RegistryEntry.Reference<Enchantment> entry = list.get(slot);
                String id = enchantId(entry);
                int current = d.enchants.getOrDefault(id, 0);
                int next = (current == 0 && dir > 0 && mul == 1)
                        ? entry.value().getMaxLevel()
                        : current + dir * mul;
                next = clamp(next, 0, 255);
                if (next <= 0) {
                    d.enchants.remove(id);
                } else {
                    d.enchants.put(id, next);
                }
            }
            showNpc();
            return;
        }
        switch (slot) {
            case 45 -> {
                ItemStack held = player.getMainHandStack();
                if (held.isEmpty()) {
                    message(player, "Возьмите предмет в руку");
                    return;
                }
                takeHeldItem(held, d);
            }
            case 46 -> d.count = clamp(d.count + dir * mul, 1, 64);
            case 47 -> d.cooldown = clamp(d.cooldown + dir * mul * 5, 0, 3600);
            case 48 -> d.typeIndex = (d.typeIndex + 1) % NPC_TYPES.size();
            case 49 -> {
                showMain();
                return;
            }
            case 50 -> {
                NpcDef def = new NpcDef();
                def.item = d.item;
                def.count = d.count;
                def.cooldown = d.cooldown;
                def.enchants = new LinkedHashMap<>(d.enchants);
                def.name = "Раздатчик: " + new ItemStack(npcItem(d)).getName().getString();
                BlockPos pos = player.getBlockPos().offset(player.getHorizontalFacing(), 2);
                boolean ok = NpcManager.create(world, pos, def, NPC_TYPES.get(d.typeIndex));
                message(player, ok ? "НПС создан: правый клик по нему выдаёт предмет" : "Не удалось создать НПС");
                return;
            }
            case 51 -> {
                boolean removed = NpcManager.removeNearest(world, player.getBlockPos());
                message(player, removed ? "НПС удалён" : "Рядом нет НПС-раздатчика");
                return;
            }
            case 52 -> d.enchants.clear();
            default -> {
                return;
            }
        }
        showNpc();
    }

    private boolean pagerClick(int slot) {
        if (slot == 48) {
            page--;
            return true;
        }
        if (slot == 50) {
            page++;
            return true;
        }
        return false;
    }

    private void clickItems(int slot, int button, boolean shift, ServerPlayerEntity player) {
        if (slot < PER_PAGE) {
            int index = page * PER_PAGE + slot;
            List<Item> list = items();
            if (index < list.size()) {
                Item item = list.get(index);
                boolean stack = shift || button == 1;
                player.getInventory().offerOrDrop(new ItemStack(item, stack ? item.getMaxCount() : 1));
            }
        } else if (pagerClick(slot)) {
            showItems();
        } else if (slot == 49) {
            showMain();
        }
    }

    private void clickMobs(int slot, int button, boolean shift, ServerPlayerEntity player) {
        if (slot < PER_PAGE) {
            int index = page * PER_PAGE + slot;
            List<EntityType<?>> list = mobs();
            if (index < list.size()) {
                spawnMobs(list.get(index), shift ? 10 : button == 1 ? 5 : 1, player);
            }
        } else if (pagerClick(slot)) {
            showMobs();
        } else if (slot == 46) {
            Draft d = draft();
            d.applyToMobs = !d.applyToMobs;
            showMobs();
        } else if (slot == 49) {
            showMain();
        }
    }

    private void spawnMobs(EntityType<?> type, int count, ServerPlayerEntity player) {
        Draft d = draft();
        BlockPos pos = player.getBlockPos().offset(player.getHorizontalFacing(), 2);
        int spawnedCount = 0;
        for (int i = 0; i < count; i++) {
            Entity spawned = type.spawn(world, pos, SpawnReason.COMMAND);
            if (spawned == null) {
                continue;
            }
            spawnedCount++;
            if (d.applyToMobs && spawned instanceof LivingEntity living) {
                for (RegistryEntry<StatusEffect> effect : d.effects) {
                    living.addStatusEffect(new StatusEffectInstance(effect, d.seconds * 20, d.level - 1));
                }
            }
        }
        message(player, "Создано: " + type.getName().getString() + " x" + spawnedCount);
    }

    private void clickPotions(int slot, boolean shift, ServerPlayerEntity player) {
        Draft d = draft();
        if (slot < PER_PAGE) {
            List<RegistryEntry.Reference<StatusEffect>> list = effects();
            if (slot < list.size()) {
                RegistryEntry.Reference<StatusEffect> effect = list.get(slot);
                if (!d.effects.remove(effect)) {
                    d.effects.add(effect);
                }
            }
            showPotions();
            return;
        }
        switch (slot) {
            case 45 -> d.level = Math.max(1, d.level - (shift ? 10 : 1));
            case 46 -> d.level = Math.min(255, d.level + (shift ? 10 : 1));
            case 47 -> d.seconds = Math.max(1, d.seconds - (shift ? 300 : 30));
            case 48 -> d.seconds = Math.min(99999, d.seconds + (shift ? 300 : 30));
            case 49 -> d.type = (d.type + 1) % 3;
            case 50 -> {
                if (d.effects.isEmpty()) {
                    message(player, "Сначала выберите эффекты");
                } else {
                    player.getInventory().offerOrDrop(buildPotion(d));
                    message(player, "Зелье выдано");
                }
            }
            case 51 -> d.effects.clear();
            case 52 -> d.applyToMobs = !d.applyToMobs;
            case 53 -> {
                showMain();
                return;
            }
            default -> {
            }
        }
        showPotions();
    }

    private static void message(ServerPlayerEntity player, String text) {
        player.sendMessage(Text.literal(text), true);
    }
}
