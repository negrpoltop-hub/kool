package com.adminmod.modules;

import com.adminmod.Module;
import com.adminmod.npc.NpcManager;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;

public class NpcModule implements Module {
    @Override
    public String id() {
        return "npc";
    }

    @Override
    public void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        PlayerModule.simple(dispatcher, "npcremove", (source, player) ->
                NpcManager.removeNearest(source.getWorld(), player.getBlockPos())
                        ? "НПС удалён" : "Рядом (6 блоков) нет НПС-раздатчика");
    }
}
