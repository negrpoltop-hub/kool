package com.adminmod.modules;

import com.adminmod.Config;
import com.adminmod.Module;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

/** Управление админами. Эти команды работают только из консоли сервера. */
public class CoreModule implements Module {
    @Override
    public String id() {
        return "core";
    }

    @Override
    public void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("adminmod")
                .requires(source -> source.getEntity() == null)
                .then(CommandManager.literal("addadmin")
                        .then(CommandManager.argument("name", StringArgumentType.word())
                                .executes(ctx -> {
                                    String name = StringArgumentType.getString(ctx, "name");
                                    if (Config.get().admins.stream().noneMatch(a -> a.equalsIgnoreCase(name))) {
                                        Config.get().admins.add(name);
                                        Config.save();
                                    }
                                    ctx.getSource().sendFeedback(() -> Text.literal("Админ добавлен: " + name), false);
                                    return 1;
                                })))
                .then(CommandManager.literal("reload")
                        .executes(ctx -> {
                            Config.load();
                            ctx.getSource().sendFeedback(() -> Text.literal("Конфиг перезагружен"), false);
                            return 1;
                        })));
    }
}
